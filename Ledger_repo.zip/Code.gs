/**
 * EXPENSE / INCOME TRACKER — Google Apps Script backend
 * --------------------------------------------------------
 * Paste this whole file into Extensions → Apps Script in your Google Sheet.
 * Then Deploy → New deployment → Web app → Execute as: Me, Access: Anyone.
 *
 * It does two jobs:
 *   1. GET  -> returns all dropdown lists (live from your sheets)
 *   2. POST -> appends a new row to Txn_Expenses or Txn_Income
 *
 * No data is ever deleted or edited. Append-only.
 */

// ============================================================
// CONFIG — change ONLY if you rename sheets/columns later
// ============================================================
var CONFIG = {
  expenseSheet: 'Txn_Expenses',
  incomeSheet:  'Txn_Income',
  listsSheet:   'Lists',
  accountsSheet:'Accounts_Master',
  budgetSheet:  'Budget_Master',
  loanSheet:    'Loans',
  netMoneySheet:'Net Money',

  // Column headers in the Lists sheet (must match exactly)
  expenseCatHeader: 'Expense Categories',
  incomeCatHeader:  'Income Categories',
  paymentModeHeader:'Payment Modes',

  accountNameHeader:'Account Name',   // in Accounts_Master
  budgetKeyHeader:  'BudgetKey'       // in Budget_Master
};

// ============================================================
// GET — serve all dropdown data to the app
// ============================================================
function doGet(e) {
  try {
    // If the app asks specifically for Net Money figures, return those.
    if (e && e.parameter && e.parameter.action === 'netMoney') {
      return jsonOut({ ok: true, data: getNetMoney() });
    }
    // Top spending categories this month.
    if (e && e.parameter && e.parameter.action === 'topCategories') {
      return jsonOut({ ok: true, data: getTopCategories(5) });
    }
    // Accounts & cards balances.
    if (e && e.parameter && e.parameter.action === 'accounts') {
      return jsonOut({ ok: true, data: getAccountsSnapshot() });
    }
    // Loans grouped by person (from the QUERY-spilled table on Loans sheet).
    if (e && e.parameter && e.parameter.action === 'loansByPerson') {
      return jsonOut({ ok: true, data: getLoansByPerson() });
    }
    // Pending email-detected transactions awaiting review.
    if (e && e.parameter && e.parameter.action === 'inbox') {
      return jsonOut({ ok: true, data: getInboxPending() });
    }
    // Force a Gmail scan right now, then return the fresh list.
    if (e && e.parameter && e.parameter.action === 'scanNow') {
      return jsonOut({ ok: true, data: inboxScanNow() });
    }
    // Last N transactions, optionally filtered by kind (expense|income).
    if (e && e.parameter && e.parameter.action === 'recent') {
      return jsonOut({ ok: true, data: getRecentTransactions(10, e.parameter.kind) });
    }

    var data = {
      expenseCategories: getColumnByHeader(CONFIG.listsSheet, CONFIG.expenseCatHeader),
      incomeCategories:  getColumnByHeader(CONFIG.listsSheet, CONFIG.incomeCatHeader),
      paymentModes:      getColumnByHeader(CONFIG.listsSheet, CONFIG.paymentModeHeader),
      accounts:          getColumnByHeader(CONFIG.accountsSheet, CONFIG.accountNameHeader),
      budgetKeys:        getColumnByHeader(CONFIG.budgetSheet, CONFIG.budgetKeyHeader)
    };
    return jsonOut({ ok: true, data: data });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

/**
 * Reads the Net Money summary figures. The six headline cells are read directly
 * from the Net Money sheet (stable cell positions). The three "This Month"
 * figures are computed with the same logic as the sheet's formulas so they
 * always match, without depending on where those cards sit.
 */
function getNetMoney() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var nm = ss.getSheetByName(CONFIG.netMoneySheet);
  if (!nm) throw new Error('Sheet not found: ' + CONFIG.netMoneySheet);

  // Fixed-cell headline values (numbers, raw — the app formats them).
  var netLeft   = nm.getRange('C4').getValue();
  var inAccount = nm.getRange('F4').getValue();
  var inWallets = nm.getRange('G4').getValue();
  var totalMoney= nm.getRange('H4').getValue();
  var ccBills   = nm.getRange('F7').getValue();
  var loansGiven= nm.getRange('F10').getValue();

  // This-month figures, computed to match the sheet's SUMIFS formulas.
  var mtd = monthToDateTotals(ss);

  return {
    netLeft:     netLeft,
    inAccount:   inAccount,
    inWallets:   inWallets,
    totalMoney:  totalMoney,
    ccBills:     ccBills,
    loansGiven:  loansGiven,
    income:      mtd.income,
    expenses:    mtd.expenses,
    cashflow:    mtd.income - mtd.expenses
  };
}

/**
 * Sums this calendar month's income and "real" expenses (excluding CC Bill,
 * Self Transfer, Top Up categories) — mirrors the sheet's formulas.
 */
function monthToDateTotals(ss) {
  var now = new Date();
  var first = new Date(now.getFullYear(), now.getMonth(), 1);
  var last  = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

  // Coerce a cell value (Date OR serial number OR blank) into a Date, or null.
  function asDate(v) {
    if (v instanceof Date) return v;
    if (typeof v === 'number' && v > 0) {
      // Google Sheets serial -> JS Date (serial 25569 == 1970-01-01)
      return new Date(Math.round((v - 25569) * 86400000));
    }
    return null;
  }

  // Income: Txn_Income, col A = date, col D = amount
  var inc = ss.getSheetByName(CONFIG.incomeSheet).getDataRange().getValues();
  var income = 0;
  for (var i = 1; i < inc.length; i++) {
    var d = asDate(inc[i][0]);
    if (d && d >= first && d <= last) income += Number(inc[i][3]) || 0;
  }

  // Expenses: Txn_Expenses, col A = date, col C = category, col F = amount
  var exclude = { 'CC Bill': 1, 'Self Transfer': 1, 'Top Up': 1 };
  var exp = ss.getSheetByName(CONFIG.expenseSheet).getDataRange().getValues();
  var expenses = 0;
  for (var j = 1; j < exp.length; j++) {
    var dd = asDate(exp[j][0]);
    var cat = String(exp[j][2]);
    if (dd && dd >= first && dd <= last && !exclude[cat]) {
      expenses += Number(exp[j][5]) || 0;
    }
  }
  return { income: income, expenses: expenses };
}

// ============================================================
// TOP SPENDING CATEGORIES (this month, sorted by amount)
// ============================================================
/**
 * Returns the top N spending categories for the current month.
 * Excludes non-spend categories (CC Bill, Self Transfer, Top Up, Reversal,
 * Loan, Transfer). Maps Investment->Investments, Subscription->Subscriptions.
 */
function getTopCategories(n) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var alias = { 'Investment': 'Investments', 'Subscription': 'Subscriptions' };
  function canon(c) { c = String(c).trim(); return alias[c] || c; }
  var EXCLUDE = { 'CC Bill':1, 'Self Transfer':1, 'Top Up':1, 'Reversal':1, 'Loan':1, 'Transfer':1 };
  // Stricter exclusions for "today's spend" headline (per user's spec):
  // excludes investments, subscriptions, miscellaneous, and transfers — these
  // are not real "spend" for the today-tracker glance. Aliased forms covered.
  var EXCLUDE_TODAY = {
    'Investment':1, 'Investments':1,
    'Subscription':1, 'Subscriptions':1,
    'Miscellaneous':1,
    'Transfer':1, 'Self Transfer':1, 'Top Up':1,
    'CC Bill':1, 'Reversal':1, 'Loan':1
  };

  var now = new Date();
  var first = new Date(now.getFullYear(), now.getMonth(), 1);
  var last  = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  // "today" boundary in the sheet's timezone, anchored to midnight.
  var todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  var todayEnd   = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
  function asDate(v) {
    if (v instanceof Date) return v;
    if (typeof v === 'number' && v > 0) return new Date(Math.round((v - 25569) * 86400000));
    return null;
  }

  var exp = ss.getSheetByName(CONFIG.expenseSheet).getDataRange().getValues();
  var totals = {};
  var todaysTotal = 0;
  for (var i = 1; i < exp.length; i++) {
    var d = asDate(exp[i][0]);
    if (!d) continue;
    var rawCat = String(exp[i][2]).trim();
    var amt = Number(exp[i][5]) || 0;

    // Top-5 grouping for the month
    if (d >= first && d <= last && !EXCLUDE[rawCat]) {
      var cc = canon(rawCat);
      totals[cc] = (totals[cc] || 0) + amt;
    }
    // Today's total — stricter exclusions
    if (d >= todayStart && d <= todayEnd && !EXCLUDE_TODAY[rawCat]) {
      todaysTotal += amt;
    }
  }

  var rows = [];
  for (var k in totals) rows.push({ category: k, amount: totals[k] });
  rows.sort(function(a, b) { return b.amount - a.amount; });
  return {
    rows: rows.slice(0, n),
    monthLabel: Utilities.formatDate(now, ss.getSpreadsheetTimeZone(), "MMMM yyyy"),
    todaysTotal: todaysTotal
  };
}

// ============================================================
// ACCOUNTS SNAPSHOT (balances per account/wallet/card)
// ============================================================
/**
 * Returns every account's current balance, grouped by type. Reads each
 * account's OWN sheet (same source of truth the Dashboard uses), driven by
 * the Account Type + Account Name listed in Accounts_Master.
 *   - Bank:        Usable Balance from cell B18 (= Current - Reserve)
 *   - Wallet:      Current Balance from cell B16
 *   - Credit Card: Current Outstanding from cell B16
 * Sheets named after the account must exist; missing ones are skipped.
 */
function getAccountsSnapshot() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var am = ss.getSheetByName(CONFIG.accountsSheet).getDataRange().getValues();
  var head = am[0];
  var typeCol = -1, nameCol = -1;
  for (var c = 0; c < head.length; c++) {
    var h = String(head[c]).trim();
    if (h === 'Account Type') typeCol = c;
    if (h === CONFIG.accountNameHeader) nameCol = c;
  }
  if (typeCol < 0 || nameCol < 0) throw new Error('Accounts_Master headers not found');

  var banks = [], wallets = [], cards = [];
  for (var r = 1; r < am.length; r++) {
    var type = String(am[r][typeCol] || '').trim();
    var name = String(am[r][nameCol] || '').trim();
    if (!name || !type) continue;
    var sheet = ss.getSheetByName(name);
    if (!sheet) continue;   // no sheet for this account — skip silently

    if (type === 'Bank') {
      banks.push({ name: name, balance: Number(sheet.getRange('B18').getValue()) || 0 });
    } else if (type === 'Wallet') {
      wallets.push({ name: name, balance: Number(sheet.getRange('B16').getValue()) || 0 });
    } else if (type === 'Credit Card') {
      cards.push({ name: name, outstanding: Number(sheet.getRange('B16').getValue()) || 0 });
    }
  }

  // Cards: split into ones with outstanding > 0 and zero-balance ones.
  cards.sort(function(a, b) { return b.outstanding - a.outstanding; });
  var active = cards.filter(function(c){ return c.outstanding > 0; });
  var zero   = cards.filter(function(c){ return c.outstanding <= 0; });
  var totalOutstanding = cards.reduce(function(s, c){ return s + c.outstanding; }, 0);

  return {
    banks: banks,
    wallets: wallets,
    cardsActive: active,
    cardsZero:   zero,
    cardsZeroCount: zero.length,
    bankTotal:   banks.reduce(function(s,b){return s+b.balance;},0),
    walletTotal: wallets.reduce(function(s,w){return s+w.balance;},0),
    cardTotal:   totalOutstanding
  };
}

// ============================================================
// LOANS BY PERSON (read from the Loans sheet's QUERY-spilled table)
// ============================================================
/**
 * Reads the BY PERSON breakdown on the Loans sheet. The source is a QUERY
 * formula in F8 that spills downward: column F = name, column G = total
 * outstanding. We walk downward from F8 until we hit a blank name row, so
 * this stays correct as borrowers are added or removed.
 */
function getLoansByPerson() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.loanSheet);
  if (!sheet) return { rows: [], total: 0 };

  var lastRow = sheet.getLastRow();
  if (lastRow < 8) return { rows: [], total: 0 };

  // Pull F8:G(lastRow). Faster than getValue per cell.
  var values = sheet.getRange(8, 6, lastRow - 7, 2).getValues();
  var rows = [];
  var total = 0;
  for (var i = 0; i < values.length; i++) {
    var name = values[i][0];
    var amount = values[i][1];
    if (name === '' || name === null || name === undefined) break;   // end of spill
    var amt = Number(amount) || 0;
    rows.push({ name: String(name).trim(), amount: amt });
    total += amt;
  }
  return { rows: rows, total: total };
}

// ============================================================
// RECENT TRANSACTIONS (last N, expenses + income mixed)
// ============================================================
/**
 * Returns the most recent N transactions across both sheets, newest first.
 * Each: { date (ISO), description, category, amount, account, kind }.
 * kind is 'expense' or 'income'. For expenses, account = From Account;
 * for income, account = To Account.
 */
function getRecentTransactions(n, kind) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  function asDate(v) {
    if (v instanceof Date) return v;
    if (typeof v === 'number' && v > 0) return new Date(Math.round((v - 25569) * 86400000));
    return null;
  }
  function iso(d) {
    return d.getFullYear() + '-' +
      ('0' + (d.getMonth() + 1)).slice(-2) + '-' +
      ('0' + d.getDate()).slice(-2);
  }

  var out = [];

  // 'idx' preserves sheet row order so that, among same-date rows, later rows
  // (appended later = more recent) sort ahead. Expenses and income get
  // separate idx ranges only matters within a kind; date is the primary key.
  if (kind !== 'income') {
    // Expenses: A date, B desc, C cat, F amount, G from account
    var exp = ss.getSheetByName(CONFIG.expenseSheet).getDataRange().getValues();
    for (var i = 1; i < exp.length; i++) {
      var d = asDate(exp[i][0]);
      if (!d) continue;
      out.push({
        date: iso(d), _t: d.getTime(), _i: i,
        description: String(exp[i][1] || ''),
        category: String(exp[i][2] || ''),
        amount: Number(exp[i][5]) || 0,
        account: String(exp[i][6] || ''),
        kind: 'expense'
      });
    }
  }

  if (kind !== 'expense') {
    // Income: A date, B desc, C cat, D amount, E to account
    var inc = ss.getSheetByName(CONFIG.incomeSheet).getDataRange().getValues();
    for (var k = 1; k < inc.length; k++) {
      var d2 = asDate(inc[k][0]);
      if (!d2) continue;
      out.push({
        date: iso(d2), _t: d2.getTime(), _i: k,
        description: String(inc[k][1] || ''),
        category: String(inc[k][2] || ''),
        amount: Number(inc[k][3]) || 0,
        account: String(inc[k][4] || ''),
        kind: 'income'
      });
    }
  }

  // Newest first: by date, then by sheet row order (later row = more recent).
  out.sort(function(a, b) {
    if (b._t !== a._t) return b._t - a._t;
    return b._i - a._i;
  });
  out = out.slice(0, n);
  out.forEach(function(o){ delete o._t; delete o._i; });
  return out;
}

// ============================================================
// POST — append a transaction
// ============================================================
function doPost(e) {
  var cache = null, reqKey = null;
  try {
    var body = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    // ---- idempotency ----------------------------------------------------
    // A save can succeed on the server while the reply is lost (slow mobile
    // connection, or Apps Script busy). The app then retries, which would
    // write the row a SECOND time. Every submission therefore carries a
    // reqId; we remember the ones we've handled and short-circuit repeats,
    // so retrying is always safe and can never duplicate a row.
    if (body.reqId) {
      cache = CacheService.getScriptCache();
      reqKey = 'req_' + body.reqId;
      var prior = cache.get(reqKey);
      if (prior) return jsonOut({ ok: true, message: prior, duplicate: true });
      cache.put(reqKey, 'Saved', 21600);   // reserve immediately (6h)
    }

    // Inbox actions that don't write a transaction row.
    if (body.type === 'inboxDismiss') {
      return jsonOut({ ok: inboxDismiss(body.inboxId), message: 'Dismissed' });
    }

    // Keep the date EXACTLY as entered by converting "YYYY-MM-DD" into the
    // spreadsheet DATE SERIAL NUMBER (integer days since 1899-12-30). A plain
    // integer carries no time and no timezone, so it can never be shifted by
    // ±1 day regardless of the script's or sheet's timezone settings. This is
    // the most robust possible way to store the date.
    var parts = String(body.date || '').split('-');
    if (parts.length !== 3) throw new Error('Bad date: ' + body.date);
    var dateValue = isoToSerial(Number(parts[0]), Number(parts[1]), Number(parts[2]));

    var msg;
    if (body.type === 'expense') {
      writeExpenseRow_(ss, body, dateValue); msg = 'Expense added';
      // "Mikku" tick: also log it in the Mahi Spends table on Net Money.
      if (body.mikku) { try { appendMikkuSpend_(ss, dateValue, body.description, Number(body.amount)); msg = 'Expense + Mahi spend added'; } catch (mk) { msg = 'Expense added (Mahi table failed: ' + mk + ')'; } }
    } else if (body.type === 'income') {
      writeIncomeRow_(ss, body, dateValue); msg = 'Income added';
    } else if (body.type === 'loan') {
      var sheetL = ss.getSheetByName(CONFIG.loanSheet);
      // Columns: Date | Name | Reason | Amount  (A–D), data starts row 8
      insertDataRow(sheetL, [dateValue, body.name, body.reason, Number(body.amount)], null);
      if (cache && reqKey) cache.put(reqKey, 'Loan added', 21600);
      return jsonOut({ ok: true, message: 'Loan added' });
    } else {
      return jsonOut({ ok: false, error: 'Unknown type: ' + body.type });
    }

    // Inbox bookkeeping. If this row came from a detected item, mark it
    // confirmed and learn the mapping. If it was a manual add, auto-dismiss
    // any pending detected item that matches it.
    try {
      if (body.inboxId) inboxAfterConfirm(ss, body.inboxId, body);
      else inboxAutoDismiss(ss, body.date, body.amount, body.type === 'expense' ? body.fromAccount : body.toAccount);
    } catch (ignore) {}

    if (cache && reqKey) cache.put(reqKey, msg, 21600);
    return jsonOut({ ok: true, message: msg });
  } catch (err) {
    // The write did NOT complete — release the reservation so a genuine
    // retry is allowed through.
    if (cache && reqKey) { try { cache.remove(reqKey); } catch (ig) {} }
    return jsonOut({ ok: false, error: String(err) });
  }
}

function writeExpenseRow_(ss, body, dateValue) {
  var sheet = ss.getSheetByName(CONFIG.expenseSheet);
  // Columns: Date | Description | Category | BudgetKey | BudgetKey(Effective) | Amount | From | To | PaymentMode
  // NOTE: Payment Mode (col I) is NOT written as a value — it is a formula
  // that derives from the From Account. insertDataRow injects that formula.
  var rowVals = [
    dateValue,
    body.description,
    body.category,
    body.budgetKey,
    body.budgetKey,                 // auto-copy into "Effective" (column E)
    Number(body.amount),
    body.fromAccount || '',
    body.toAccount   || ''
  ];
  insertDataRow(sheet, rowVals, { col: 9, ref: 'G' });   // PaymentMode in col I, keys off From Account (G)
}

/**
 * Appends to the "Mahi Spends" table on the Net Money sheet (headers row 28,
 * data from row 29: C=Date, D=Reason, E=Amount; F/G are formulas on row 29).
 *
 * The range is a real table (Mikku_spends) and the total uses a structured
 * reference, so a plain write below the last row risks landing OUTSIDE the
 * table and being left out of the sum. To guarantee the table grows, we insert
 * a row INSIDE the existing range and then shuffle the last entry down by one,
 * which keeps the rows in date order and keeps the new row inside the table.
 */
function appendMikkuSpend_(ss, dateValue, description, amount) {
  var sh = ss.getSheetByName(CONFIG.netMoneySheet);
  if (!sh) throw new Error('Net Money sheet not found');
  var FIRST = 29;

  // find the last row that has a date in column C
  var scanTo = Math.max(sh.getLastRow(), FIRST);
  var col = sh.getRange(FIRST, 3, scanTo - FIRST + 1, 1).getValues();
  var lastData = FIRST - 1;
  for (var i = 0; i < col.length; i++) if (col[i][0] !== '' && col[i][0] !== null) lastData = FIRST + i;

  var row = [dateValue, String(description || ''), Number(amount) || 0];

  if (lastData < FIRST) {                 // empty table — just write the first row
    sh.getRange(FIRST, 3, 1, 3).setValues([row]);
    sh.getRange(FIRST, 3).setNumberFormat('ddd, d mmm yyyy');
    return;
  }

  // Insert inside the table so its range expands, then keep date order by
  // moving the previous last entry up into the gap and writing ours below it.
  var prev = sh.getRange(lastData, 3, 1, 3).getValues()[0];
  sh.insertRowBefore(lastData);
  sh.getRange(lastData,     3, 1, 3).setValues([prev]);
  sh.getRange(lastData + 1, 3, 1, 3).setValues([row]);
  sh.getRange(lastData, 3, 2, 1).setNumberFormat('ddd, d mmm yyyy');
}

function writeIncomeRow_(ss, body, dateValue) {
  var sheet2 = ss.getSheetByName(CONFIG.incomeSheet);
  // Columns: Date | Description | Income Category | Amount | To Account | Payment Mode
  // NOTE: Payment Mode (col F) is a formula deriving from To Account (E).
  var rowVals2 = [
    dateValue,
    body.description,
    body.category,
    Number(body.amount),
    body.toAccount || ''
  ];
  insertDataRow(sheet2, rowVals2, { col: 6, ref: 'E' });   // PaymentMode in col F, keys off To Account (E)
}

/**
 * Inserts a transaction row immediately AFTER the last row that has data in
 * column A (the Date column) — not at the bottom of the sheet's used range.
 * Then copies the formatting (number format, font, colours, data validation)
 * from that last data row onto the new row, so it visually matches.
 *
 * @param {Sheet}  sheet   target sheet (Txn_Expenses or Txn_Income)
 * @param {Array}  values  row values, left-to-right, starting at column A
 * @param {Object} pmSpec  payment-mode formula spec: { col: <1-based col of
 *                         Payment Mode>, ref: <column letter the formula keys
 *                         off, 'G' for expenses / 'E' for income> }
 */
function insertDataRow(sheet, values, pmSpec) {
  // 1) Find the last row with content in column A.
  var colA = sheet.getRange('A1:A').getValues();   // all of column A
  var lastDataRow = 0;
  for (var r = colA.length - 1; r >= 0; r--) {
    if (colA[r][0] !== '' && colA[r][0] !== null) { lastDataRow = r + 1; break; }
  }
  if (lastDataRow === 0) throw new Error('No data found in column A of ' + sheet.getName());

  var newRow = lastDataRow + 1;
  var numCols = values.length;

  // 2) Make sure the destination row physically exists.
  if (newRow > sheet.getMaxRows()) {
    sheet.insertRowsAfter(sheet.getMaxRows(), 1);
  }

  // 3) Copy formatting (incl. number format + data validation) from the last
  //    data row onto the new row. We copy across the FULL width up to and
  //    including the Payment Mode column, so that column's format carries too.
  var formatCols = Math.max(numCols, pmSpec ? pmSpec.col : numCols);
  var sourceRange = sheet.getRange(lastDataRow, 1, 1, formatCols);
  var destRange   = sheet.getRange(newRow, 1, 1, formatCols);
  sourceRange.copyTo(destRange, SpreadsheetApp.CopyPasteType.PASTE_FORMAT, false);

  // 4) Write the date cell. values[0] is the date SERIAL NUMBER (an integer).
  //    Writing a pure number means no timezone or locale can shift the day.
  //    The cell's date number-format (copied from the row above) renders it
  //    as a readable date like the other rows.
  sheet.getRange(newRow, 1, 1, 1).setValue(values[0]);

  if (numCols > 1) {
    var rest = values.slice(1);
    sheet.getRange(newRow, 2, 1, numCols - 1).setValues([rest]);
  }

  // 5) Inject the Payment Mode FORMULA (matching the existing rows) so it
  //    auto-derives from the account — exactly like every other row.
  if (pmSpec && pmSpec.col) {
    var ref = pmSpec.ref + newRow;   // e.g. "G615" or "E127"
    var formula =
      '=IFERROR(IF(' + ref + '="","",' +
      'IF(INDEX(Accounts_Master!A:A,MATCH(' + ref + ',Accounts_Master!B:B,0))="Bank","UPI",' +
      'IF(INDEX(Accounts_Master!A:A,MATCH(' + ref + ',Accounts_Master!B:B,0))="Wallet","Wallet",' +
      'IF(INDEX(Accounts_Master!A:A,MATCH(' + ref + ',Accounts_Master!B:B,0))="Credit Card","Credit Card","")))),"")';
    sheet.getRange(newRow, pmSpec.col, 1, 1).setFormula(formula);
  }
}

// ============================================================
// HELPERS
// ============================================================

// Reads a single column under a given header, returns clean non-empty values.
function getColumnByHeader(sheetName, header) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  if (!sheet) throw new Error('Sheet not found: ' + sheetName);

  var values = sheet.getDataRange().getValues();
  var headerRow = values[0];
  var colIndex = -1;
  for (var c = 0; c < headerRow.length; c++) {
    if (String(headerRow[c]).trim() === header) { colIndex = c; break; }
  }
  if (colIndex === -1) throw new Error('Header not found: "' + header + '" in ' + sheetName);

  var out = [];
  for (var r = 1; r < values.length; r++) {
    var v = values[r][colIndex];
    if (v !== '' && v !== null && v !== undefined) out.push(String(v).trim());
  }
  return out;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Converts a calendar date (year, month, day) into the spreadsheet date serial
 * number (integer days since 1899-12-30), using pure integer arithmetic with
 * no Date object — so it is completely immune to timezone/locale shifts.
 * Verified: 2026-05-25 -> 46167, 2026-05-26 -> 46168 (matches the sheet).
 */
function isoToSerial(y, m, d) {
  var yy = y - (m <= 2 ? 1 : 0);
  var era = Math.floor(yy / 400);
  var yoe = yy - era * 400;
  var doy = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
  var doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  var days = era * 146097 + doe - 719468;   // days since 1970-01-01
  return days + 25569;                       // shift to 1899-12-30 epoch
}

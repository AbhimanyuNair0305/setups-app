# Ledger — Personal Expense & Income Logger

A lightweight Progressive Web App (PWA) for quickly logging expenses and income
from an iPhone, writing directly into a Google Sheets personal-finance tracker.

Built to replace the daily chore of manually editing a spreadsheet — open the
app, tap in a transaction, and it lands in the right sheet with correct
formatting, dates, and formula-driven fields, instantly.

## How it works

```
iPhone home-screen PWA  ──HTTPS──▶  Google Apps Script Web App  ──▶  Google Sheet
   (index.html)                        (Code.gs: doGet/doPost)        (Txn_Expenses /
                                                                        Txn_Income)
```

- **Frontend** — a single `index.html` PWA (HTML/CSS/vanilla JS). Installs to the
  iPhone home screen, runs full-screen, works offline.
- **Backend** — a Google Apps Script bound to the spreadsheet:
  - `doGet` serves dropdown data (categories, accounts, budget keys) read **live**
    from the sheet, so the app always reflects the latest lists.
  - `doPost` appends a transaction to the correct sheet.
- **Storage** — the existing Google Sheets tracker. No separate database.

## Notable engineering details

- **Smart row insertion** — appends after the last *real* data row (scans the
  Date column) rather than the bottom of the sheet's used range, so rows land in
  the right place even when the sheet has trailing formatted-but-empty rows.
- **Format inheritance** — new rows copy number format and data validation from
  the row above, so dates render correctly and dropdowns carry over.
- **Timezone-proof dates** — the date is written as an ISO string parsed by the
  sheet itself, avoiding the classic phantom-time (e.g. `23:30:00`) artifact from
  script/sheet timezone mismatches.
- **Formula-driven Payment Mode** — rather than writing a static value, the
  backend injects the same lookup formula the existing rows use, so Payment Mode
  auto-derives from the account (Bank→UPI, Wallet→Wallet, Credit Card→Credit Card)
  and stays consistent with the rest of the sheet.
- **Offline queue** — if offline at submit time, the entry is queued locally and
  auto-synced when the connection returns.

## Tech

- HTML / CSS / vanilla JavaScript (no framework, no build step)
- PWA: web app manifest + service worker (offline app shell)
- Google Apps Script (backend)
- Google Sheets (data store)
- Hosting: Netlify (deployed from this private repo)

## Files

| File | Purpose |
|------|---------|
| `index.html` | The PWA — UI + logic |
| `manifest.json` | PWA manifest (home-screen install) |
| `sw.js` | Service worker (offline app shell) |
| `icon.png` | App icon |
| `Code.gs` | Google Apps Script backend (lives in the bound Sheet's Apps Script project) |

## Setup (for reference)

1. Convert the tracker spreadsheet to Google Sheets.
2. In the Sheet: **Extensions → Apps Script**, paste `Code.gs`, deploy as a Web
   app (Execute as: Me, Access: Anyone with the link). Copy the `/exec` URL.
3. Put that URL into `index.html` (`SCRIPT_URL`).
4. Deploy the four frontend files to a static host.
5. On iPhone Safari: open the URL → Share → Add to Home Screen.

---

*Private project. The deployed `SCRIPT_URL` is a personal endpoint and is not
intended for public distribution.*

## Email auto-detection (Inbox.gs)

Bank and card alert emails are scanned every 2 hours by Apps Script and parked in an
`Inbox` sheet. The app shows a "N transactions detected" strip on the Add tab; tapping
an item pre-fills the form. Nothing is written to the transaction sheets until you confirm.

**One-time setup**
1. Apps Script editor → `+` → Script → name it `Inbox` → paste `Inbox.gs` → Save.
2. Paste the updated `Code.gs` over the existing one → Save.
3. In the editor, pick `setupInbox` from the function dropdown → Run. Grant Gmail access
   when prompted. This creates the `Inbox`, `Inbox_Seen` and `Inbox_Learn` sheets and
   installs the trigger. Only mail received after this moment is ever scanned.
4. Deploy → Manage deployments → edit → New version → Deploy.

**Adding a new bank later**: add a parser function in `Inbox.gs`, register it in
`INBOX_PARSERS`, and add the card's last four digits to `INBOX_DIGIT_MAP`.

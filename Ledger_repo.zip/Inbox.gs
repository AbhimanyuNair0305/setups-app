// ============================================================
// Inbox.gs — email-detected transactions. Companion to Code.gs.
// Setup:  run setupInbox() once (Gmail access + hourly scan trigger).
// Notify: set notifyVia + credentials in INBOX_CFG, then testNotify().
// Debug:  every scan logs what it decided about each mail.
//         inboxExplain(q) — why a given mail was or was not used.
//         inboxRescan(d)  — re-examine the last d days after a parser fix.
//         inboxDiagnose() — times a scan, lists parsed vs ignored mail.
// ============================================================

// ============================================================
// INBOX PARSERS — pure functions, no Apps Script APIs.
// Each parser takes (subject, body, mailDate) and returns either null
// (not a transaction mail) or a normalised object:
//   { kind:'debit'|'credit', amount, dateISO, digits, account, counterparty,
//     vpa, ref, balance, balanceType, source }
// Shared by Inbox.gs (via copy) and by the local Node test harness.
// ============================================================

var INBOX_DIGIT_MAP = {
  // digits -> Accounts_Master name
  '0581': 'HDFC Account',
  '0521': 'Axis Account',
  '9040': 'Slice Account',
  '4441': 'Infinia',
  '0340': 'Swiggy HDFC',
  '5613': 'MyZone',
  '0932': 'Supermoney',
  '2052': 'Axis Neo',
  '7566': 'SBI Cashback',
  '8008': 'Amazon ICICI',
  '5006': 'ICICI Coral',
  '4663': 'HSBC Live+',
  '7313': 'SalarySe',
  '7073': 'IndusInd Tiger',
  '8459': 'Kiwi Yesbank'
};

// Maps card names as they appear in bill-reminder mails to Accounts_Master names.
var INBOX_CARD_NAME_HINTS = [
  [/amazon pay icici/i, 'Amazon ICICI'],
  [/icici bank credit card/i, 'Amazon ICICI'],
  [/hsbc/i, 'HSBC Live+'],
  [/sbi card|sbi credit/i, 'SBI Cashback'],
  [/swiggy hdfc/i, 'Swiggy HDFC'],
  [/infinia/i, 'Infinia'],
  [/indusind/i, 'IndusInd Tiger'],
  [/salaryse|city union/i, 'SalarySe'],
  [/yes bank|yesbank|kiwi/i, 'Kiwi Yesbank'],
  [/axis bank credit card/i, 'Axis Neo']
];
function cardFromName_(txt){
  for (var i=0;i<INBOX_CARD_NAME_HINTS.length;i++) if (INBOX_CARD_NAME_HINTS[i][0].test(txt)) return INBOX_CARD_NAME_HINTS[i][1];
  return null;
}

// Words in a payee/VPA that mark a bank debit as a probable card bill.
var INBOX_BILL_WORDS = ['billpay', 'cred', 'bill', 'cardpay', 'card payment', 'creditcard', 'ccpay', 'payzapp'];

function _num(s){ return Number(String(s).replace(/[,\s]/g,'')) || 0; }
function _pad(n){ return ('0'+n).slice(-2); }
var _MON = {jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12};

// Accepts: DD-MM-YY, DD-MM-YYYY, DD/MM/YY, DD/MM/YYYY, "03 Sep, 2026", "03 Sep 2026",
// "Sep 12, 2026", "08-Sep-26", "08-Sep-2026". Returns "YYYY-MM-DD" or null.
function parseAnyDate(s){
  if(!s) return null;
  s = String(s).trim();
  var m;
  if((m = s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{2}|\d{4})$/))){
    var y = m[3].length===2 ? 2000+Number(m[3]) : Number(m[3]);
    return y+'-'+_pad(m[2])+'-'+_pad(m[1]);
  }
  if((m = s.match(/^(\d{1,2})[-\s]([A-Za-z]{3})[a-z]*,?[-\s](\d{2}|\d{4})$/))){
    var y2 = m[3].length===2 ? 2000+Number(m[3]) : Number(m[3]);
    var mo = _MON[m[2].toLowerCase().slice(0,3)]; if(!mo) return null;
    return y2+'-'+_pad(mo)+'-'+_pad(m[1]);
  }
  if((m = s.match(/^([A-Za-z]{3})[a-z]*\s+(\d{1,2}),?\s+(\d{4})$/))){
    var mo2 = _MON[m[1].toLowerCase().slice(0,3)]; if(!mo2) return null;
    return m[3]+'-'+_pad(mo2)+'-'+_pad(m[2]);
  }
  return null;
}
function dateToISO(d){ return d.getFullYear()+'-'+_pad(d.getMonth()+1)+'-'+_pad(d.getDate()); }
function _acct(digits){ return INBOX_DIGIT_MAP[digits] || null; }
function _clean(s){ return String(s||'').replace(/\s+/g,' ').replace(/[.\s]+$/,'').trim(); }

// ---------- individual parsers ----------

function parseHDFCAccount(subject, body, mailDate){
  var m;
  // credit
  m = body.match(/Rs\.?\s*([\d,]+\.?\d*)\s+has been successfully credited to your HDFC Bank account ending in\s*(\d{4})/i);
  if(m){
    var d = (body.match(/Date:\s*(\d{2}-\d{2}-\d{2,4})/i)||[])[1];
    var sender = (body.match(/Sender:\s*([^\n(]+)/i)||[])[1];
    var vpa = (body.match(/VPA:\s*([^\s)]+)/i)||[])[1];
    var ref = (body.match(/UPI Reference No\.?:\s*(\d+)/i)||[])[1];
    return { kind:'credit', amount:_num(m[1]), dateISO: parseAnyDate(d)||dateToISO(mailDate),
             digits:m[2], account:_acct(m[2]), counterparty:_clean(sender), vpa:vpa||'', ref:ref||'', source:'HDFC Account' };
  }
  // debit
  m = body.match(/Rs\.?\s*([\d,]+\.?\d*)\s+is debited from your account ending\s*(\d{4})\s+towards VPA\s*(\S+)\s*\(([^)]*)\)\s*on\s*(\d{2}-\d{2}-\d{2,4})/i);
  if(m){
    var ref2 = (body.match(/UPI transaction reference no\.?:\s*(\d+)/i)||[])[1];
    return { kind:'debit', amount:_num(m[1]), dateISO: parseAnyDate(m[5])||dateToISO(mailDate),
             digits:m[2], account:_acct(m[2]), counterparty:_clean(m[4]), vpa:m[3], ref:ref2||'', source:'HDFC Account' };
  }
  return null;
}

function parseHDFCCard(subject, body, mailDate){
  var m = body.match(/Rs\.?\s*([\d,]+\.?\d*)\s+has been debited from your HDFC Bank Credit Card ending\s*(\d{4})\s+towards\s+(.+?)\s+on\s+(\d{1,2}\s+[A-Za-z]{3},?\s+\d{4})/i);
  if(!m) return null;
  return { kind:'debit', amount:_num(m[1]), dateISO: parseAnyDate(m[4])||dateToISO(mailDate),
           digits:m[2], account:_acct(m[2]), counterparty:_clean(m[3]), vpa:'', ref:'', source:'HDFC Card' };
}

function parseAxisCard(subject, body, mailDate){
  if(!/Axis Bank Credit Card No/i.test(body)) return null;
  var amt = (body.match(/Transaction Amount:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  var merch = (body.match(/Merchant Name:\s*([^\n\t]+)/i)||[])[1];
  var dig = (body.match(/Credit Card No\.?\s*X+(\d{4})/i)||[])[1];
  var dt = (body.match(/Date\s*&\s*Time:\s*(\d{2}-\d{2}-\d{4})/i)||[])[1];
  var lim = (body.match(/Available Limit\*?:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  if(!amt || !dig) return null;
  return { kind:'debit', amount:_num(amt), dateISO: parseAnyDate(dt)||dateToISO(mailDate),
           digits:dig, account:_acct(dig), counterparty:_clean(merch), vpa:'', ref:'',
           balance: lim?_num(lim):null, balanceType: lim?'availableLimit':null, source:'Axis Card' };
}

function parseAxisAccount(subject, body, mailDate){
  if(!/Account Number:\s*X+\d{4}/i.test(body)) return null;
  var cr = (body.match(/Amount Credited:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  var dr = (body.match(/Amount Debited:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  if(!cr && !dr) return null;
  var dig = (body.match(/Account Number:\s*X+(\d{4})/i)||[])[1];
  var dt = (body.match(/Date\s*&\s*Time:\s*(\d{2}-\d{2}-\d{2,4})/i)||[])[1];
  var info = _clean((body.match(/Transaction Info:\s*([^\n]+)/i)||[])[1]);
  // "UPI/P2A/623909762617/KARATH AB/HDFC/Paid" or "UPI/P2M/659301708923/ROYAL TAKE AWAY"
  var parts = info.split('/');
  var ref = parts.length>2 ? parts[2] : '';
  var who = parts.length>3 ? parts[3] : info;
  return { kind: cr?'credit':'debit', amount:_num(cr||dr), dateISO: parseAnyDate(dt)||dateToISO(mailDate),
           digits:dig, account:_acct(dig), counterparty:_clean(who), vpa:'', ref:ref, rawInfo:info, source:'Axis Account' };
}

function parseSliceAccount(subject, body, mailDate){
  var m = body.match(/received\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)\s+via UPI in your slice bank account\s*x+(\d{4})/i);
  if(!m) return null;
  var bal = (body.match(/Avl\.?\s*Bal\.?\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)/i)||[])[1];
  var dt = (body.match(/Transaction date\s*(\d{1,2}-[A-Za-z]{3}-\d{2,4})/i)||[])[1];
  var from = (body.match(/From\s+([^\n\t]+?)\s*(?:\n|\t|RRN)/i)||[])[1];
  var rrn = (body.match(/RRN\s*(\d+)/i)||[])[1];
  return { kind:'credit', amount:_num(m[1]), dateISO: parseAnyDate(dt)||dateToISO(mailDate),
           digits:m[2], account:_acct(m[2]), counterparty:_clean(from), vpa:'', ref:rrn||'',
           balance: bal?_num(bal):null, balanceType: bal?'balance':null, source:'Slice Account' };
}

function parseAmazonPay(subject, body, mailDate){
  var m;
  m = body.match(/payment for Rs\.?\s*([\d,]+\.?\d*)\s+on\s+(\S+)\s+was successful/i);
  if(m){
    var bal = (body.match(/Amazon Pay balance\s*Rs\.?\s*([\d,]+\.?\d*)/i)||[])[1];
    return { kind:'debit', amount:_num(m[1]), dateISO: dateToISO(mailDate), digits:'', account:'Amazon Pay Balance',
             counterparty:_clean(m[2]), vpa:'', ref:'', balance: bal?_num(bal):null, balanceType: bal?'balance':null, source:'Amazon Pay' };
  }
  m = body.match(/Here.s\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)\s*cashback/i);
  if(m){
    var bal2 = (body.match(/Updated Amazon Pay Balance\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)/i)||[])[1];
    return { kind:'credit', amount:_num(m[1]), dateISO: dateToISO(mailDate), digits:'', account:'Amazon Pay Balance',
             counterparty:'Amazon Pay Cashback', vpa:'', ref:'', isCashback:true,
             balance: bal2?_num(bal2):null, balanceType: bal2?'balance':null, source:'Amazon Pay' };
  }
  return null;
}

function parseSBICard(subject, body, mailDate){
  var m = body.match(/Rs\.?\s*([\d,]+\.?\d*)\s+spent on your SBI Credit Card ending\s*(\d{4})\s+at\s+(.+?)\s+on\s+(\d{2}\/\d{2}\/\d{2,4})/i);
  if(!m) return null;
  return { kind:'debit', amount:_num(m[1]), dateISO: parseAnyDate(m[4])||dateToISO(mailDate),
           digits:m[2], account:_acct(m[2]), counterparty:_clean(m[3]), vpa:'', ref:'', source:'SBI Card' };
}

function parseICICICard(subject, body, mailDate){
  var m = body.match(/ICICI Bank Credit Card\s*X+(\d{4})\s+has been used for a transaction of INR\s*([\d,]+\.?\d*)\s+on\s+([A-Za-z]{3}\s+\d{1,2},?\s+\d{4})/i);
  if(!m) return null;
  var info = (body.match(/Info:\s*([^.\n]+)/i)||[])[1];
  var lim = (body.match(/Available Credit Limit on your card is INR\s*([\d,]+\.?\d*)/i)||[])[1];
  return { kind:'debit', amount:_num(m[2]), dateISO: parseAnyDate(m[3])||dateToISO(mailDate),
           digits:m[1], account:_acct(m[1]), counterparty:_clean(info), vpa:'', ref:'',
           balance: lim?_num(lim):null, balanceType: lim?'availableLimit':null, source:'ICICI Card' };
}

function parseHSBCCard(subject, body, mailDate){
  var m = body.match(/HSBC Credit Card\s*x+(\d{4})\s+was used for a transaction of INR\s*([\d,]+\.?\d*)\s+at\s+(.+?)\s+on\s+(\d{2}\/\d{2}\/\d{2,4})/i);
  if(!m) return null;
  var lim = (body.match(/Available limit:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  var due = (body.match(/Amount due:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  return { kind:'debit', amount:_num(m[2]), dateISO: parseAnyDate(m[4])||dateToISO(mailDate),
           digits:m[1], account:_acct(m[1]), counterparty:_clean(m[3]), vpa:'', ref:'',
           balance: lim?_num(lim):null, balanceType: lim?'availableLimit':null, amountDue: due?_num(due):null, source:'HSBC Card' };
}

function parseSalarySe(subject, body, mailDate){
  var m = body.match(/amount of\s*(?:₹\s*)?(?:Rs\.?\s*)?([\d,]+\.?\d*)\s+was spent on\s+(\d{2}-\d{2}-\d{4})[^]*?ending with\s*(\d{4})\s+at\s+(.+?)\s*\.\s*$/im);
  if(!m) return null;
  var merch = _clean(m[4]).replace(/^IN at\s+/i,'');
  var out = (body.match(/outstanding balance after this transaction is\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)/i)||[])[1];
  return { kind:'debit', amount:_num(m[1]), dateISO: parseAnyDate(m[2])||dateToISO(mailDate),
           digits:m[3], account:_acct(m[3]), counterparty:merch, vpa:'', ref:'',
           balance: out?_num(out):null, balanceType: out?'outstanding':null, source:'SalarySe' };
}

function parseIndusIndCard(subject, body, mailDate){
  var m = body.match(/transaction on your IndusInd Bank Credit Card ending\s*(\d{4})\s+for INR\s*([\d,]+\.?\d*)\s+on\s+(\d{2}-\d{2}-\d{4})[^]*?\bat\s+(.+?)\s+is\s+Approved/i);
  if(!m) return null;
  var lim = (body.match(/Available Limit:\s*INR\s*([\d,]+\.?\d*)/i)||[])[1];
  return { kind:'debit', amount:_num(m[2]), dateISO: parseAnyDate(m[3])||dateToISO(mailDate),
           digits:m[1], account:_acct(m[1]), counterparty:_clean(m[4]), vpa:'', ref:'',
           balance: lim?_num(lim):null, balanceType: lim?'availableLimit':null, source:'IndusInd Card' };
}

// Monthly reward points from the Amazon Pay ICICI card, credited to the wallet.
function parseICICIRewardPoints(subject, body, mailDate){
  if(!/reward points/i.test(body) || !/Amazon Pay ICICI/i.test(body)) return null;
  var m = body.match(/Amazon Pay eGift Card\s*(?:₹|Rs\.?)\s*([\d,]+\.?\d*)/i);
  if(!m) return null;
  return { kind:'credit', amount:_num(m[1]), dateISO: dateToISO(mailDate), digits:'', account:'Amazon Pay Balance',
           counterparty:'ICICI Cashback', vpa:'', ref:'', isICICIReward:true, source:'ICICI Rewards' };
}

// Amazon refund back to the original payment method.
function parseAmazonRefund(subject, body, mailDate){
  var m = body.match(/refund for\s*(?:\u20B9|Rs\.?|INR)?\s*([\d,]+\.?\d*)\s+has been processed/i);
  if(!m) return null;
  // Where the money went. Check the card line first — the mail also contains
  // generic boilerplate mentioning Amazon Pay balance, which must not win.
  var dig = (body.match(/Card\s*\[ending with\s*(\d{4})\]/i)||[])[1];
  var acct = dig ? _acct(dig) : null;
  if(!acct && /Amazon Pay balance\s*:?\s*(?:\u20B9|Rs\.?)\s*[\d,]/i.test(body)) acct = 'Amazon Pay Balance';
  if(!acct) return null;
  var order = (body.match(/Order\s*#\s*([\d-]+)/i)||[])[1];
  return { kind:'credit', amount:_num(m[1]), dateISO: dateToISO(mailDate), digits:dig||'',
           account:acct, counterparty:'Amazon Refund', vpa:'', ref:order||'',
           isRefund:true, source:'Amazon Refund' };
}

var INBOX_PARSERS = [
  parseHDFCAccount, parseHDFCCard, parseAxisCard, parseAxisAccount,
  parseSliceAccount, parseAmazonRefund, parseAmazonPay, parseSBICard, parseICICICard, parseHSBCCard, parseSalarySe, parseIndusIndCard, parseICICIRewardPoints
];

// ---------- credit-card bill alerts (not transactions) ----------
// Kiwi, CRED, Amazon Pay reminders and the bank's own statement mail all
// announce the SAME bill. Each returns the same {card, dueDateISO} so the
// engine can collapse them into one alert.
function parseBillAlert(subject, body, mailDate){
  var hay = (subject||'') + '\n' + body;
  var isBill = /bill (is ready|for your|payment is due|has been generated)|Credit Card Statement|statement for the period|total amount due|Total Amount Due/i.test(hay);
  if(!isBill) return null;
  // must not be a spend confirmation
  if(/was used for a transaction|is debited|has been debited|spent on your|is Approved/i.test(body)) return null;

  var digits = (body.match(/(?:x{2,}|X{2,}|•{2,})[\s-]*(\d{4})\b/)||[])[1]
            || (body.match(/ending(?:\s+with)?\s+(\d{4})\b/i)||[])[1] || null;
  var card = digits ? (INBOX_DIGIT_MAP[digits]||null) : null;
  if(!card) card = cardFromName_(hay);
  if(!card) return null;

  var total = (body.match(/total amount due[:\s]*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i)||[])[1];
  var minDue = (body.match(/minimum (?:amount )?due[:\s]*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i)||[])[1];
  // Search subject AND body — Kiwi puts the due date only in the subject line.
  var dueRaw = (hay.match(/(?:payment )?due date[:\s\t]*([0-9]{1,2}[-\/][0-9]{1,2}[-\/][0-9]{2,4})/i)||[])[1]
            || (hay.match(/due date[:\s\t]*([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})/i)||[])[1]
            || (hay.match(/due date[:\s\t]*(\d{1,2}[-\s][A-Za-z]{3,9},?[-\s]\d{2,4})/i)||[])[1]
            || (hay.match(/due (?:on|by)\s+([0-9]{1,2}[-\/][0-9]{1,2}[-\/][0-9]{2,4})/i)||[])[1]
            || (hay.match(/due (?:on|by)\s+([0-9]{1,2}[-\s][A-Za-z]{3,9},?[-\s]\d{2,4})/i)||[])[1]
            || (hay.match(/due (?:on|by)\s+([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})/i)||[])[1]
            || (hay.match(/due\s*\n?\s*by\s+([A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})/i)||[])[1];
  var dueISO = dueRaw ? parseAnyDate(_clean(dueRaw)) : null;
  if(!total && !dueISO) return null;   // too vague to be useful

  return { kind:'billalert', card:card, digits:digits||'', amountDue: total?_num(total):null,
           minDue: minDue?_num(minDue):null, dueDateISO: dueISO||'', source:'Bill Alert' };
}

// Runs every parser, returns the first hit. OTP / statement / gift-card
// mails match none of the confirmation patterns and fall through as null.
function parseTransactionMail(subject, body, mailDate){
  var b = String(body||'').replace(/\r/g,'');
  var alert = parseBillAlert(subject, b, mailDate);
  if(alert) return alert;
  for(var i=0;i<INBOX_PARSERS.length;i++){
    try{ var r = INBOX_PARSERS[i](subject||'', b, mailDate); if(r && r.amount>0) return r; }catch(e){}
  }
  return null;
}

// Probable card-bill test for a BANK debit.
function looksLikeBillPayment(p){
  if(!p || p.kind!=='debit') return false;
  var hay = ((p.vpa||'')+' '+(p.counterparty||'')+' '+(p.rawInfo||'')).toLowerCase();
  for(var i=0;i<INBOX_BILL_WORDS.length;i++) if(hay.indexOf(INBOX_BILL_WORDS[i])>=0) return true;
  return false;
}


// ============================================================
// INBOX ENGINE — Gmail scan → Inbox sheet → app review → Txn sheets
// ============================================================
var INBOX_CFG = {
  sheet:      'Inbox',
  seenSheet:  'Inbox_Seen',
  learnSheet: 'Inbox_Learn',
  // Gmail search. Keyword filter keeps the read volume small; parsers decide.
  // Quoted PHRASES, not bare words. The first version used single words like
  // "cashback" and "amount due", which matched piles of marketing mail — every
  // match costs a getPlainBody() fetch, and that made scans slow enough to
  // starve the web app. Phrases are specific to real alert wording.
  gmailQuery: 'newer_than:3d -in:spam -in:trash ('
    + '"is debited" OR "has been debited" OR "successfully credited" OR "was credited" '
    + 'OR "spent on your" OR "was spent on" OR "used for a transaction" OR "is Approved" '
    + 'OR "have received" OR "payment for Rs" OR "reward points" OR "refund for" '
    + 'OR "summary of your" OR "Amount Debited" OR "Amount Credited" '
    + 'OR "Transaction Amount" OR "Amazon Pay eGift Card" '
    + 'OR "bill is ready" OR "bill payment is due" OR "bill for your" '
    + 'OR "Total Amount Due" OR "total amount due" OR "Credit Card Statement"'
    + ')',
  daysBack: 3,
  maxThreads: 80,
  triggerEveryHours: 1,
  seenRetainDays: 7,
  historyRows: 500,          // how many recent Txn rows to use for dedup + suggestions
  billAmountTolerance: 5,    // rupees, for "closest bill" fallback

  // Recurring fixed-fare rule: a debit of exactly this amount from this
  // account is almost always the daily rickshaw to the gym.
  fixedFare: { amount: 20, account: 'HDFC Account',
               desc: 'Tirri', category: 'Travel', budgetKey: 'Travel | Fixed' },

  // ---- Phone notifications ----
  // 'telegram' (free, recommended), 'pushover' (paid app, very reliable),
  // 'email'    (no setup, arrives as a mail), or 'none' to switch off.
  // NOTE: ntfy.sh is NOT usable here — Google blocks it from Apps Script
  // (UrlFetchApp returns "Address unavailable"). That is why this is pluggable.
  notifyVia: 'telegram',

  // Telegram: message @BotFather → /newbot → copy the token here. Then send
  // your bot any message and run getTelegramChatId() to fill in the chat id.
  telegramToken:  'REPLACE_WITH_BOT_TOKEN',
  telegramChatId: 'REPLACE_WITH_CHAT_ID',

  // Pushover (optional alternative): keys from pushover.net
  pushoverUser:  '',
  pushoverToken: '',

  appUrl: 'https://abhimanyu-ledger.netlify.app'
};

var INBOX_COLS = ['ID','DetectedAt','Status','Kind','Date','Amount','Account','ToAccount','Counterparty',
                  'SuggDesc','SuggCategory','SuggBudgetKey','Confidence','Balance','BalanceType','Source','Subject','VPA','Ref','PairedID','Note','DueDate','MinDue'];

// ---------- one-time setup (run from the editor) ----------
function setupInbox() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureInboxSheets_(ss);
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('INBOX_SINCE')) props.setProperty('INBOX_SINCE', String(Date.now()));
  // replace any existing scan trigger
  ScriptApp.getProjectTriggers().forEach(function(t){
    if (t.getHandlerFunction() === 'scanGmailForTransactions') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('scanGmailForTransactions').timeBased().everyHours(INBOX_CFG.triggerEveryHours).create();
  // touch Gmail once so the auth scope is granted now, not at 2am
  GmailApp.getInboxUnreadCount();
  Logger.log('Inbox ready. Scanning mail newer than ' + new Date(Number(props.getProperty('INBOX_SINCE'))) + ' every ' + INBOX_CFG.triggerEveryHours + 'h.');
}

function ensureInboxSheets_(ss) {
  var sh = ss.getSheetByName(INBOX_CFG.sheet);
  if (!sh) {
    sh = ss.insertSheet(INBOX_CFG.sheet);
    sh.getRange(1,1,1,INBOX_COLS.length).setValues([INBOX_COLS]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  var seen = ss.getSheetByName(INBOX_CFG.seenSheet);
  if (!seen) { seen = ss.insertSheet(INBOX_CFG.seenSheet); seen.getRange(1,1,1,2).setValues([['MsgID','SeenAt']]); seen.hideSheet(); }
  var learn = ss.getSheetByName(INBOX_CFG.learnSheet);
  if (!learn) { learn = ss.insertSheet(INBOX_CFG.learnSheet); learn.getRange(1,1,1,7).setValues([['Key','Description','Category','BudgetKey','ToAccount','Count','LastUsed']]); learn.hideSheet(); }
  return sh;
}

// ---------- the scheduled job ----------
function scanGmailForTransactions() {
  // Only one scan at a time. Without this, an hourly trigger and a manual
  // "check now" can pile up and starve the web app of execution slots.
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) { Logger.log('Another scan is already running — skipped.'); return; }
  try { scanGmailForTransactions_(); } finally { lock.releaseLock(); }
}
function scanGmailForTransactions_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ensureInboxSheets_(ss);
  var props = PropertiesService.getScriptProperties();
  var since = Number(props.getProperty('INBOX_SINCE') || 0);
  if (!since) { since = Date.now(); props.setProperty('INBOX_SINCE', String(since)); }

  var seenSh = ss.getSheetByName(INBOX_CFG.seenSheet);
  var seen = {};
  var seenVals = seenSh.getDataRange().getValues();
  for (var i = 1; i < seenVals.length; i++) if (seenVals[i][0]) seen[seenVals[i][0]] = true;

  _histCache = null; _learnCache = null; _bksCache = null; _billsCache = null;   // fresh per scan
  var existing = readInboxRows_(sh);          // all rows incl. status
  var pending  = existing.filter(function(r){ return r.Status === 'pending'; });
  var known    = loadTxnFingerprints_(ss);    // already-logged transactions
  var ownAccts = loadOwnAccounts_(ss);        // name -> type

  var threads = GmailApp.search(INBOX_CFG.gmailQuery, 0, INBOX_CFG.maxThreads);
  var newSeen = [], fresh = [], unparsed = [];
  threads.forEach(function(t){
    t.getMessages().forEach(function(m){
      var id = m.getId();
      if (seen[id]) return;
      newSeen.push([id, new Date()]);
      if (m.getDate().getTime() < since) return;
      var p = parseTransactionMail(m.getSubject(), m.getPlainBody(), m.getDate());
      if (!p) { unparsed.push(m.getFrom().slice(0, 40) + ' | ' + m.getSubject().slice(0, 55)); return; }
      if (p.kind === 'billalert') { p.id = id; p.subject = m.getSubject(); fresh.push(p); return; }
      if (!p.account) return;
      p.id = id; p.subject = m.getSubject();
      fresh.push(p);
    });
  });

  // dedup against logged txns, against pending inbox, and within this batch
  var batchKeys = {};
  var items = [];
  var alertKeys = {};
  existing.forEach(function(r){ if (r.Kind === 'billalert' && r.Status !== 'dismissed') alertKeys[String(r.Account)+'|'+String(r.DueDate)] = r; });

  // Reference numbers (UPI ref / RRN) identify a transaction EXACTLY. Two
  // alert mails about one payment share a ref; two separate payments never do.
  var seenRefs = {};
  existing.forEach(function(r){ if (r.Ref) seenRefs[String(r.Ref).trim()] = true; });

  // How many rows with a given fingerprint we've already accounted for.
  // Seeded with what's already pending so a rescan doesn't re-add them.
  var used = {};
  pending.forEach(function(r){ var f = fingerprint_(r.Date, r.Amount, r.Account); used[f] = (used[f]||0)+1; });

  fresh.forEach(function(p){
    if (p.kind === 'billalert') {
      var ak = p.card + '|' + p.dueDateISO;
      var prev = alertKeys[ak];
      if (prev) {
        // same bill from another app — enrich the existing row, never duplicate
        var changed = false;
        if (p.amountDue && !prev.Amount) { prev.Amount = p.amountDue; changed = true; }
        if (p.minDue && !prev.MinDue)    { prev.MinDue = p.minDue;    changed = true; }
        if (changed) prev._dirty = true;
        return;
      }
      var row = { ID:p.id, DetectedAt:new Date(), Status:'pending', Kind:'billalert', Date:p.dueDateISO,
                  Amount:p.amountDue||'', Account:p.card, ToAccount:'', Counterparty:'', SuggDesc:'', SuggCategory:'',
                  SuggBudgetKey:'', Confidence:'', Balance:'', BalanceType:'', Source:p.source||'', Subject:p.subject||'',
                  VPA:'', Ref:'', PairedID:'', Note:'', DueDate:p.dueDateISO, MinDue:p.minDue||'' };
      alertKeys[ak] = row; items.push(row);
      return;
    }
    var ref = String(p.ref || '').trim();
    if (ref && seenRefs[ref]) { items.push(toRow_(p, 'dismissed', 'duplicate alert (same reference)')); return; }

    var fp = fingerprint_(p.dateISO, p.amount, p.account);
    var already  = known[fp] || 0;      // rows in the sheet that look like this
    var consumed = used[fp]  || 0;      // how many we've already matched up
    if (consumed < already) {
      used[fp] = consumed + 1;
      if (ref) seenRefs[ref] = true;
      items.push(toRow_(p, 'auto', 'already in sheet'));
      return;
    }
    // With no reference we can't tell a repeat alert from a second identical
    // payment, so fall back to one-per-fingerprint within a single scan.
    if (!ref && batchKeys[fp]) { items.push(toRow_(p, 'dismissed', 'duplicate alert')); return; }
    if (ref) seenRefs[ref] = true;
    batchKeys[fp] = true;
    used[fp] = consumed + 1;
    items.push(toRow_(p, 'pending', ''));
  });

  // enrich pending items: transfers, bills, suggestions
  var pendingNow = pending.concat(items.filter(function(r){ return r.Status === 'pending'; }));
  pairSelfTransfers_(pendingNow, ownAccts);
  var bills = null;
  pendingNow.forEach(function(r){
    if (r.Kind === 'transfer' || r.Kind === 'billalert' || r._enriched) return;
    if (r.Kind === 'debit' && ownAccts[r.Account] === 'Bank') {
      if (!bills) bills = computeCardBills_(ss);
      var b = matchBill_(r, bills);
      if (b) { r.Kind = 'bill'; r.ToAccount = b.card || ''; r.Confidence = b.confidence; r.Note = b.note;
               r.SuggDesc = (b.card ? b.card : 'Card') + ' Bill'; r.SuggCategory = 'CC Bill'; r.SuggBudgetKey = 'Transfer | Credit Card Payment'; }
    }
    if (r.Kind === 'debit' || r.Kind === 'credit') suggest_(ss, r);
    r._enriched = true;
  });

  // write: update existing pending rows that changed, append new rows
  writeInboxRows_(sh, existing, items);
  if (newSeen.length) seenSh.getRange(seenSh.getLastRow()+1, 1, newSeen.length, 2).setValues(newSeen);
  pruneSeen_(seenSh);
  // Log what happened to EVERY parsed mail. When something looks "missed",
  // this line says whether it was deduped, dismissed or genuinely never seen,
  // without needing a separate diagnostic run.
  items.forEach(function(r){
    Logger.log('  ' + String(r.Status).toUpperCase().padEnd(10) + ' ' +
               String(r.Kind).padEnd(10) + ' ' + String(r.Amount).padEnd(10) + ' ' +
               String(r.Date).padEnd(12) + ' ' + String(r.Account).padEnd(18) + ' ' +
               String(r.Counterparty || r.SuggDesc || '').slice(0, 26) +
               (r.Note ? '   (' + r.Note + ')' : ''));
  });
  var newPending = items.filter(function(r){ return r.Status === 'pending'; });
  try {
    var stillPending = readInboxRows_(sh).filter(function(r){ return r.Status === 'pending'; }).length;
    PropertiesService.getScriptProperties().setProperty('INBOX_PENDING', String(stillPending));
  } catch (e) {}
  Logger.log('Scanned ' + newSeen.length + ' new mails, ' + newPending.length + ' new pending items.');
  if (unparsed.length) {
    Logger.log('Matched the search but no parser understood them (' + unparsed.length + '):');
    unparsed.slice(0, 15).forEach(function(u){ Logger.log('  no-parse: ' + u); });
  }
  if (newPending.length) { try { notifyPhone_(newPending); } catch (err) { Logger.log('notify failed: ' + err); } }
}

// ---------- phone notification ----------
// Builds the message body once, then hands it to whichever provider is set.
function buildNotifyText_(rows) {
  var lines = rows.slice(0, 5).map(function(r){
    var amt = '\u20B9' + Number(r.Amount).toLocaleString('en-IN');
    var who = r.SuggDesc || r.Counterparty || r.Account;
    var tag = r.Kind === 'credit' ? '+' : (r.Kind === 'transfer' ? '\u21C4 ' : (r.Kind === 'bill' ? 'bill ' : ''));
    return tag + amt + ' ' + who + ' \u00B7 ' + r.Account;
  });
  if (rows.length > 5) lines.push('+' + (rows.length - 5) + ' more');
  return lines.join('\n');
}

function notifyPhone_(rows) {
  var n = rows.length;
  var title = n === 1 ? '1 transaction to review' : n + ' transactions to review';
  var text  = buildNotifyText_(rows);
  var via   = String(INBOX_CFG.notifyVia || 'none').toLowerCase();

  if (via === 'telegram') return notifyTelegram_(title, text);
  if (via === 'pushover') return notifyPushover_(title, text);
  if (via === 'email')    return notifyEmail_(title, text);
  return false;   // 'none'
}

function notifyTelegram_(title, text) {
  var tok = String(INBOX_CFG.telegramToken || '').trim();
  var chat = String(INBOX_CFG.telegramChatId || '').trim();
  if (!tok || tok.indexOf('REPLACE') === 0 || !chat || chat.indexOf('REPLACE') === 0) {
    Logger.log('Telegram not configured — skipping notification.'); return false;
  }
  var res = UrlFetchApp.fetch('https://api.telegram.org/bot' + tok + '/sendMessage', {
    method: 'post', contentType: 'application/json',
    payload: JSON.stringify({
      chat_id: chat,
      text: '*' + title + '*\n' + text + '\n\n[Open Ledger](' + INBOX_CFG.appUrl + ')',
      parse_mode: 'Markdown', disable_web_page_preview: true
    }),
    muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code !== 200) Logger.log('Telegram failed (' + code + '): ' + res.getContentText().slice(0, 300));
  return code === 200;
}

function notifyPushover_(title, text) {
  var u = String(INBOX_CFG.pushoverUser || '').trim(), t = String(INBOX_CFG.pushoverToken || '').trim();
  if (!u || !t) { Logger.log('Pushover not configured — skipping.'); return false; }
  var res = UrlFetchApp.fetch('https://api.pushover.net/1/messages.json', {
    method: 'post',
    payload: { token: t, user: u, title: title, message: text, url: INBOX_CFG.appUrl, url_title: 'Open Ledger' },
    muteHttpExceptions: true
  });
  var code = res.getResponseCode();
  if (code !== 200) Logger.log('Pushover failed (' + code + '): ' + res.getContentText().slice(0, 300));
  return code === 200;
}

// Zero-setup fallback: mails you. Subject is tagged so it can never be picked
// up by the scanner, and so you can set an iPhone VIP/notification rule on it.
function notifyEmail_(title, text) {
  MailApp.sendEmail({ to: Session.getEffectiveUser().getEmail(),
                      subject: '[Ledger] ' + title,
                      body: text + '\n\nOpen Ledger: ' + INBOX_CFG.appUrl });
  return true;
}

// Run this AFTER sending your bot a message in Telegram. It finds your chat id
// and logs it — paste the number into telegramChatId above.
function getTelegramChatId() {
  var tok = String(INBOX_CFG.telegramToken || '').trim();
  if (!tok || tok.indexOf('REPLACE') === 0) { Logger.log('Set telegramToken first.'); return; }
  var res = UrlFetchApp.fetch('https://api.telegram.org/bot' + tok + '/getUpdates', { muteHttpExceptions: true });
  var body = res.getContentText();
  if (res.getResponseCode() !== 200) { Logger.log('Telegram error: ' + body.slice(0, 300)); return; }
  var data = JSON.parse(body);
  if (!data.result || !data.result.length) {
    Logger.log('No messages yet. Open Telegram, send your bot any message (e.g. "hi"), then run this again.'); return;
  }
  var seen = {};
  data.result.forEach(function(u){
    var m = u.message || u.edited_message || u.channel_post; if (!m || !m.chat) return;
    if (seen[m.chat.id]) return; seen[m.chat.id] = true;
    Logger.log('chat id: ' + m.chat.id + '   (' + (m.chat.first_name || m.chat.title || m.chat.type) + ')');
  });
  Logger.log('Paste the chat id above into INBOX_CFG.telegramChatId');
}

// Explains exactly what the scanner did with specific mails. Pass any Gmail
// search text, e.g. inboxExplain('HSBC 169') or inboxExplain('from:hsbc.co.in').
// For each match it says: was it seen before, is it in the scan window, does it
// parse, and would it be treated as a duplicate.
function inboxExplain(search) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var since = Number(PropertiesService.getScriptProperties().getProperty('INBOX_SINCE') || 0);
  var seenSh = ss.getSheetByName(INBOX_CFG.seenSheet);
  var seen = {};
  if (seenSh) { var sv = seenSh.getDataRange().getValues(); for (var i = 1; i < sv.length; i++) if (sv[i][0]) seen[sv[i][0]] = true; }
  var known = loadTxnFingerprints_(ss);
  var q = search || ('newer_than:' + INBOX_CFG.daysBack + 'd');
  var threads = GmailApp.search(q, 0, 25);
  if (!threads.length) { Logger.log('No mail matches: ' + q); return; }
  threads.forEach(function(t){
    t.getMessages().forEach(function(m){
      var why = [];
      if (seen[m.getId()]) why.push('ALREADY SEEN (skipped; ids are remembered ' + INBOX_CFG.seenRetainDays + ' days)');
      if (m.getDate().getTime() < since) why.push('OLDER than scan start (' + new Date(since) + ')');
      var p = parseTransactionMail(m.getSubject(), m.getPlainBody(), m.getDate());
      if (!p) why.push('NO PARSER MATCHED');
      else if (p.kind === 'billalert') why.push('parses as BILL ALERT ' + p.card + ' due ' + p.amountDue);
      else if (!p.account) why.push('parsed but account unknown (digits ' + p.digits + ')');
      else {
        why.push('parses OK: ' + p.kind + ' ' + p.amount + ' ' + p.dateISO + ' ' + p.account + ' | ' + p.counterparty);
        if (known[fingerprint_(p.dateISO, p.amount, p.account)]) why.push('DEDUPED — a row with this date+amount+account already exists in your sheet');
      }
      Logger.log(m.getDate().toISOString().slice(0,10) + '  ' + m.getSubject().slice(0,45) + '\n    -> ' + why.join('\n    -> '));
    });
  });
}

// After a parser fix, previously-scanned mail is still on the "seen" list and
// would never be looked at again. This forgets the last N days of seen ids and
// rescans, so newly-supported formats get picked up. Safe: anything already in
// your sheet is recognised and marked 'auto' rather than re-added.
function inboxRescan(days) {
  days = days || INBOX_CFG.daysBack;
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var seenSh = ss.getSheetByName(INBOX_CFG.seenSheet);
  if (seenSh) {
    var vals = seenSh.getDataRange().getValues();
    var cutoff = Date.now() - days * 86400000;
    var keep = [vals[0]];
    for (var i = 1; i < vals.length; i++) {
      var t = vals[i][1] instanceof Date ? vals[i][1].getTime() : 0;
      if (t < cutoff) keep.push(vals[i]);
    }
    seenSh.clearContents();
    seenSh.getRange(1, 1, keep.length, 2).setValues(keep);
    Logger.log('Forgot ' + (vals.length - keep.length) + ' seen ids from the last ' + days + ' day(s).');
  }
  scanGmailForTransactions();
  var p = getInboxPending();
  Logger.log('Pending now: ' + p.count + ' transactions, ' + p.alerts.length + ' bill alert(s)');
}

// Sends one fake notification through whichever provider is configured.
function testNotify() {
  var ok = notifyPhone_([{ Kind:'debit', Amount:123.45, SuggDesc:'Test from Ledger', Counterparty:'', Account:'HDFC Account' }]);
  Logger.log(ok ? ('Sent via ' + INBOX_CFG.notifyVia + ' — check your phone.')
                : ('Nothing sent. notifyVia=' + INBOX_CFG.notifyVia + ' — see the message above for why.'));
}

// Run from the editor to check how heavy a scan is. Logs the query, how many
// threads match, and how long a full scan takes. A healthy scan is a few seconds.
function inboxDiagnose() {
  var q = INBOX_CFG.gmailQuery;
  Logger.log('Query: ' + q);
  var t0 = Date.now();
  var threads = GmailApp.search(q, 0, INBOX_CFG.maxThreads);
  var msgs = 0;
  threads.forEach(function(t){ msgs += t.getMessageCount(); });
  Logger.log('Matched ' + threads.length + ' threads / ' + msgs + ' messages in ' + (Date.now()-t0) + 'ms');
  var hit = 0, miss = 0;
  threads.forEach(function(t){
    t.getMessages().forEach(function(m){
      var p = parseTransactionMail(m.getSubject(), m.getPlainBody(), m.getDate());
      if (p && p.kind === 'billalert') { hit++; Logger.log('  ALERT  ' + p.card + ' due ' + p.amountDue + ' by ' + p.dueDateISO + '   [' + m.getSubject().slice(0,50) + ']'); }
      else if (p && p.account)          { hit++; Logger.log('  OK     ' + p.kind + ' ' + p.amount + ' ' + p.dateISO + ' ' + p.account + ' | ' + p.counterparty); }
      else                              { miss++; Logger.log('  no-parse: ' + m.getFrom().slice(0,45) + ' | ' + m.getSubject().slice(0,60)); }
    });
  });
  Logger.log(hit + ' parsed, ' + miss + ' ignored');
  var t1 = Date.now();
  scanGmailForTransactions();
  Logger.log('Full scan took ' + (Date.now()-t1) + 'ms');
  var p = getInboxPending();
  Logger.log('Pending now: ' + p.count + ' transactions, ' + p.alerts.length + ' bill alert(s)');
}

// Run this from the editor once to confirm the phone receives notifications.
function testNtfy() {
  notifyPhone_([{ Kind:'debit', Amount:123.45, SuggDesc:'Test from Ledger', Counterparty:'', Account:'HDFC Account' }]);
  Logger.log('Sent test notification to topic: ' + INBOX_CFG.ntfyTopic);
}

// ---------- helpers: sheet IO ----------
function readInboxRows_(sh) {
  var vals = sh.getDataRange().getValues();
  var out = [];
  for (var i = 1; i < vals.length; i++) {
    if (!vals[i][0]) continue;
    var o = { _row: i+1 };
    INBOX_COLS.forEach(function(c, j){ o[c] = vals[i][j]; });
    if (o.Date instanceof Date) o.Date = dateToISO(o.Date);
    out.push(o);
  }
  return out;
}
function rowToArray_(o) { return INBOX_COLS.map(function(c){ return o[c] === undefined || o[c] === null ? '' : o[c]; }); }
function writeInboxRows_(sh, existing, newItems) {
  existing.forEach(function(o){ if (o._dirty) sh.getRange(o._row, 1, 1, INBOX_COLS.length).setValues([rowToArray_(o)]); });
  if (newItems.length) {
    var start = sh.getLastRow() + 1;
    sh.getRange(start, 1, newItems.length, INBOX_COLS.length).setValues(newItems.map(rowToArray_));
    sh.getRange(start, 5, newItems.length, 1).setNumberFormat('yyyy-mm-dd');
  }
}
function toRow_(p, status, note) {
  return { ID:p.id, DetectedAt:new Date(), Status:status, Kind:p.kind, Date:p.dateISO, Amount:p.amount,
           Account:p.account, ToAccount:'', Counterparty:p.counterparty||'', SuggDesc:'', SuggCategory:'', SuggBudgetKey:'',
           Confidence:'', Balance:p.balance==null?'':p.balance, BalanceType:p.balanceType||'', Source:p.source||'',
           Subject:p.subject||'', VPA:p.vpa||'', Ref:p.ref||'', PairedID:'', Note:note||'', DueDate:'', MinDue:'',
           _isCashback: !!p.isCashback, _isICICIReward: !!p.isICICIReward, _isRefund: !!p.isRefund, _rawInfo: p.rawInfo||'' };
}
function pruneSeen_(seenSh) {
  var vals = seenSh.getDataRange().getValues();
  var cutoff = Date.now() - INBOX_CFG.seenRetainDays*86400000;
  var keep = [vals[0]];
  for (var i = 1; i < vals.length; i++) { var t = vals[i][1] instanceof Date ? vals[i][1].getTime() : 0; if (t >= cutoff) keep.push(vals[i]); }
  if (keep.length < vals.length) { seenSh.clearContents(); seenSh.getRange(1,1,keep.length,2).setValues(keep); }
}

// ---------- dedup ----------
function fingerprint_(dateISO, amount, account) { return dateISO + '|' + Math.round(Number(amount)*100) + '|' + String(account).trim().toLowerCase(); }
function pendingHas_(pending, fp) {
  for (var i = 0; i < pending.length; i++) if (fingerprint_(pending[i].Date, pending[i].Amount, pending[i].Account) === fp) return true;
  return false;
}
// Returns fp -> COUNT of matching rows. Counting matters: two identical ₹20
// rickshaw fares on the same day are two real transactions, not a duplicate,
// so a boolean "seen this fingerprint" would silently swallow the second one.
function loadTxnFingerprints_(ss) {
  var known = {};
  function grab(sheetName, amtCol, acctCol, acct2Col) {
    var sh = ss.getSheetByName(sheetName); if (!sh) return;
    var last = sh.getLastRow(); var start = Math.max(2, last - INBOX_CFG.historyRows);
    if (last < 2) return;
    var vals = sh.getRange(start, 1, last - start + 1, Math.max(amtCol, acctCol, acct2Col||0)).getValues();
    vals.forEach(function(r){
      var d = r[0]; if (!(d instanceof Date)) return;
      var iso = dateToISO(d);
      if (r[acctCol-1]) { var k1 = fingerprint_(iso, r[amtCol-1], r[acctCol-1]); known[k1] = (known[k1]||0)+1; }
      if (acct2Col && r[acct2Col-1]) { var k2 = fingerprint_(iso, r[amtCol-1], r[acct2Col-1]); known[k2] = (known[k2]||0)+1; }
    });
  }
  grab(CONFIG.expenseSheet, 6, 7, 8);   // amount F, from G, to H
  grab(CONFIG.incomeSheet,  4, 5, null); // amount D, to E
  return known;
}
function loadOwnAccounts_(ss) {
  var vals = ss.getSheetByName(CONFIG.accountsSheet).getDataRange().getValues();
  var m = {};
  for (var i = 1; i < vals.length; i++) if (vals[i][1]) m[String(vals[i][1]).trim()] = String(vals[i][0]).trim();
  return m;
}

// ---------- self-transfer pairing ----------
function pairSelfTransfers_(pending, ownAccts) {
  var debits  = pending.filter(function(r){ return r.Kind==='debit'  && r.Status==='pending' && ownAccts[r.Account]; });
  var credits = pending.filter(function(r){ return r.Kind==='credit' && r.Status==='pending' && ownAccts[r.Account]; });
  debits.forEach(function(d){
    for (var i = 0; i < credits.length; i++) {
      var c = credits[i];
      if (c._used || c.Account === d.Account) continue;
      if (c.Date === d.Date && Math.abs(Number(c.Amount) - Number(d.Amount)) < 0.01) {
        d.Kind = 'transfer'; d.ToAccount = c.Account; d.PairedID = c.ID; d.Confidence = 'high';
        d.SuggDesc = 'Self transfer'; d.SuggCategory = 'Self Transfer'; d.SuggBudgetKey = 'Transfer | Account';
        d.Note = 'paired with credit on ' + c.Account; d._dirty = true;
        c.Status = 'merged'; c.PairedID = d.ID; c.Note = 'merged into transfer from ' + d.Account; c._dirty = true; c._used = true;
        break;
      }
    }
  });
}

// ---------- bill matching ----------
var _billsCache = null;
function computeCardBills_(ss) {
  if (_billsCache) return _billsCache;
  var am = ss.getSheetByName(CONFIG.accountsSheet).getDataRange().getValues();
  var exp = ss.getSheetByName(CONFIG.expenseSheet).getDataRange().getValues();
  var today = new Date(); today.setHours(0,0,0,0);
  var cards = [];
  for (var i = 1; i < am.length; i++) {
    if (String(am[i][0]).trim() !== 'Credit Card') continue;
    var name = String(am[i][1]).trim(); if (!name) continue;
    var sh = ss.getSheetByName(name);
    var current = sh ? (Number(sh.getRange('B16').getValue()) || 0) : null;
    var opening = Number(am[i][2]) || 0;
    var sd = parseInt(String(am[i][5]||'').replace(/\D/g,''), 10);
    var stmtBal = null, stmtDate = null;
    if (sd >= 1 && sd <= 31) {
      stmtDate = new Date(today.getFullYear(), today.getMonth(), Math.min(sd, 28));
      if (stmtDate > today) stmtDate = new Date(today.getFullYear(), today.getMonth()-1, Math.min(sd, 28));
      var spend = 0, paid = 0;
      for (var r = 1; r < exp.length; r++) {
        var d = exp[r][0]; if (!(d instanceof Date) || d > stmtDate) continue;
        var amt = Number(exp[r][5]) || 0;
        if (String(exp[r][6]).trim() === name) spend += amt;
        if (String(exp[r][7]).trim() === name) paid  += amt;
      }
      stmtBal = opening + spend - paid;
    }
    cards.push({ name:name, current:current, stmtBal:stmtBal, stmtDate: stmtDate ? dateToISO(stmtDate) : '' });
  }
  _billsCache = cards;
  return cards;
}
function matchBill_(r, cards) {
  var amt = Number(r.Amount);
  var isBillish = looksLikeBillPayment({ kind:'debit', vpa:r.VPA, counterparty:r.Counterparty, rawInfo:r._rawInfo });
  var exactStmt = cards.filter(function(c){ return c.stmtBal !== null && Math.abs(c.stmtBal - amt) < 0.01; });
  if (exactStmt.length === 1) return { card:exactStmt[0].name, confidence:'high', note:'matches statement balance as of ' + exactStmt[0].stmtDate };
  var exactCur = cards.filter(function(c){ return c.current !== null && Math.abs(c.current - amt) < 0.01; });
  if (exactCur.length === 1) return { card:exactCur[0].name, confidence:'high', note:'matches current outstanding' };
  if (!isBillish && !exactStmt.length && !exactCur.length) return null;
  var best = null, bestDiff = INBOX_CFG.billAmountTolerance + 0.001;
  cards.forEach(function(c){
    [c.stmtBal, c.current].forEach(function(v){ if (v === null) return; var dd = Math.abs(v - amt); if (dd < bestDiff) { bestDiff = dd; best = c; } });
  });
  if (best) return { card:best.name, confidence:'medium', note:'closest bill, off by ' + bestDiff.toFixed(2) };
  if (exactStmt.length > 1) return { card:'', confidence:'low', note:'several cards match ' + amt + ', pick one' };
  return { card:'', confidence:'low', note:'looks like a bill, card not identified' };
}

// ---------- suggestions ----------
var INBOX_SEED = [
  // [pattern, category, budgetKey]  — FIRST match wins, so the most specific
  // patterns must come first. "SWIGGY PVT LTD GROCE" is Instamart (groceries),
  // not Swiggy food, so it has to be tested before the generic Swiggy rule.
  [/SWIGGY[^A-Z]*(PVT[^A-Z]*LTD[^A-Z]*)?GROCE|INSTAMART/i, 'Groceries', 'Groceries | Order'],
  [/BLINKIT|ZEPTO|BIG\s*BASKET|BIGBASKET|AMAZON\s*NOW|AMAZON\s*FRESH|AMAZON PAY IN GROCERY|GROFERS/i, 'Groceries', 'Groceries | Order'],
  [/SWIGGY|ZOMATO|BISTRO|SWISH/i, 'Food', 'Food | Order'],
  [/UBER|RAPIDO/i, 'Travel', 'Travel | Adhoc'],
  [/EATCLUB|DOMINO|MCDONALD|KFC|BURGER|PIZZA|CAFE|RESTAUR|TAKE AWAY|DHABA|BIRYANI/i, 'Food', ''],
  [/DMART|RELIANCE FRESH|GROCERY|SUPERMARKET/i, 'Groceries', ''],
  [/IRCTC|INDIGO|AIR INDIA|VISTARA|AKASA|REDBUS|METRO|PETROL|HP PAY|IOCL|BPCL|FASTAG|PARKING/i, 'Travel', ''],
  [/NETFLIX|SPOTIFY|PRIME VIDEO|HOTSTAR|APPLE\.COM|ITUNES|GOOGLE\s*(PLAY|ONE|STORAGE)|CLAUDE|ANTHROPIC|OPENAI|YOUTUBE|ADOBE|MICROSOFT/i, 'Subscription', ''],
  [/MEDICAL|PHARM|APOLLO|CHEMIST|SALON|BARBER|SPA|GYM|CULT/i, 'Personal Care', ''],
  [/WINE|LIQUOR|BEER|BAR\b|PUB\b/i, 'Alcohol', ''],
  [/BOOKMYSHOW|PVR|INOX|CINEMA|DISTRICT/i, 'Outing', ''],
  [/ELECTRIC|BSES|TATA POWER|GAS|WATER|BROADBAND|JIO|AIRTEL|VI\b|VODAFONE|BESCOM|MAINTENANCE|RENT/i, 'Household', '']
];
function merchantKey_(s) {
  return String(s||'').toUpperCase().replace(/^RSP\*|^PAYTM\*|^RAZ\*|^PAYU\*|^CCA\*|^PPI\*/,'').replace(/[^A-Z ]+/g,' ').replace(/\s+/g,' ').trim().split(' ').slice(0,2).join(' ');
}
function prettify_(s) {
  var k = String(s||'').replace(/^RSP\*|^PAYTM\*|^RAZ\*|^PAYU\*/i,'').replace(/\s+/g,' ').trim();
  return k.toLowerCase().replace(/\b\w/g, function(c){ return c.toUpperCase(); });
}
function loadLearn_(ss) {
  var sh = ss.getSheetByName(INBOX_CFG.learnSheet); var vals = sh.getDataRange().getValues(); var m = {};
  for (var i = 1; i < vals.length; i++) if (vals[i][0]) m[vals[i][0]] = { desc:vals[i][1], cat:vals[i][2], bk:vals[i][3], to:vals[i][4], count:Number(vals[i][5])||0, row:i+1 };
  return m;
}
function saveLearn_(ss, key, desc, cat, bk, to) {
  if (!key) return;
  var sh = ss.getSheetByName(INBOX_CFG.learnSheet); var m = loadLearn_(ss);
  if (m[key]) sh.getRange(m[key].row, 2, 1, 6).setValues([[desc, cat, bk, to||'', m[key].count+1, new Date()]]);
  else sh.appendRow([key, desc, cat, bk, to||'', 1, new Date()]);
  _learnCache = null;
}
function budgetKeysByCategory_(ss) {
  var vals = ss.getSheetByName(CONFIG.budgetSheet).getDataRange().getValues(); var m = {};
  var alias = { 'Investment':'Investments', 'Subscription':'Subscriptions' };
  for (var i = 1; i < vals.length; i++) { var k = String(vals[i][0]||'').trim(); if (!k) continue; var pre = k.split('|')[0].trim(); (m[pre] = m[pre]||[]).push(k); if (alias[pre]) (m[alias[pre]] = m[alias[pre]]||[]).push(k); }
  for (var a in alias) if (m[alias[a]] && !m[a]) m[a] = m[alias[a]];
  return m;
}
var _histCache = null;
function historyByToken_(ss) {
  if (_histCache) return _histCache;
  var sh = ss.getSheetByName(CONFIG.expenseSheet); var last = sh.getLastRow(); var start = Math.max(2, last - INBOX_CFG.historyRows);
  var vals = last >= 2 ? sh.getRange(start, 1, last-start+1, 8).getValues() : [];
  var byTok = {};
  vals.forEach(function(r){
    var desc = String(r[1]||'').toUpperCase(); if (!desc) return;
    desc.split(/[^A-Z]+/).forEach(function(t){ if (t.length < 4) return; var e = (byTok[t] = byTok[t]||{}); var key = String(r[2])+'\u0001'+String(r[3]); e[key] = (e[key]||0)+1; });
  });
  _histCache = byTok; return byTok;
}
var _learnCache = null, _bksCache = null;
function suggest_(ss, r) {
  var learn = _learnCache || (_learnCache = loadLearn_(ss));
  var key = merchantKey_(r.Counterparty);
  var bks = _bksCache || (_bksCache = budgetKeysByCategory_(ss));
  if (r.Kind === 'credit') {
    if (r._isRefund) { r.SuggDesc = 'Amazon Refund'; r.SuggCategory = 'Refund'; r.Confidence = 'high'; return; }
    if (r._isICICIReward) { r.SuggDesc = 'ICICI Cashback'; r.SuggCategory = 'Cashback'; r.Confidence = 'high'; return; }
    if (r._isCashback) { r.SuggDesc = 'Cashback'; r.SuggCategory = 'Cashback'; r.Confidence = 'high'; return; }
    if (learn[key]) { r.SuggDesc = learn[key].desc; r.SuggCategory = learn[key].cat; r.Confidence = 'high'; return; }
    r.SuggDesc = prettify_(r.Counterparty); r.SuggCategory = ''; r.Confidence = 'low'; return;
  }
  // debit
  // HARD RULES FIRST. These merchant -> category + BudgetKey mappings are fixed
  // and must beat anything learned, because a single learned entry can capture
  // an unrelated merchant: "AMAZON PAY IN GROCERY" and an Amazon Pay wallet
  // top-up both reduce to the key "AMAZON PAY", so a top-up once confirmed as
  // Transfer | Wallet Loadup was hijacking every Amazon grocery order.
  for (var hi = 0; hi < INBOX_SEED.length; hi++) {
    if (!INBOX_SEED[hi][2]) continue;                     // only the fixed ones
    if (!INBOX_SEED[hi][0].test(r.Counterparty)) continue;
    r.SuggDesc = prettify_(r.Counterparty);
    r.SuggCategory = INBOX_SEED[hi][1];
    r.SuggBudgetKey = INBOX_SEED[hi][2];
    r.Confidence = 'high';
    return;
  }
  if (learn[key]) { r.SuggDesc = learn[key].desc; r.SuggCategory = learn[key].cat; r.SuggBudgetKey = learn[key].bk; r.ToAccount = learn[key].to || ''; r.Confidence = 'high'; return; }
  var cat = '', bk = '', conf = 'low';
  var hist = historyByToken_(ss);
  var toks = key.split(' ').filter(function(t){ return t.length >= 4; });
  var best = null, bestN = 0;
  toks.forEach(function(t){ var e = hist[t]; if (!e) return; for (var k in e) if (e[k] > bestN) { bestN = e[k]; best = k; } });
  if (best) { var p = best.split('\u0001'); cat = p[0]; bk = p[1]; conf = bestN >= 2 ? 'high' : 'medium'; }
  // Seed rules. A seed BudgetKey overrides a weaker history guess, because
  // these merchant->key mappings are fixed and don't change.
  for (var i = 0; i < INBOX_SEED.length; i++) {
    if (!INBOX_SEED[i][0].test(r.Counterparty)) continue;
    if (!cat) { cat = INBOX_SEED[i][1]; conf = 'medium'; }
    if (INBOX_SEED[i][2] && cat === INBOX_SEED[i][1]) { bk = INBOX_SEED[i][2]; conf = 'high'; }
    break;
  }
  // Recurring fixed fare (daily rickshaw): exact amount from a given account.
  var ff = INBOX_CFG.fixedFare;
  if (ff && !cat && Number(r.Amount) === Number(ff.amount) && String(r.Account) === String(ff.account)) {
    r.SuggDesc = ff.desc; r.SuggCategory = ff.category; r.SuggBudgetKey = ff.budgetKey;
    r.Confidence = 'medium'; r.Note = (r.Note ? r.Note + ' · ' : '') + 'matched fixed-fare rule';
    return;
  }
  var valid = {}; for (var vc in bks) bks[vc].forEach(function(k){ valid[k] = true; });
  if (bk && !valid[bk]) bk = '';                       // drop truncated/stale keys
  if (cat && !bk) {
    var list = bks[cat] || [];
    if (list.length === 1) bk = list[0];
    else if (list.length > 1) {
      // prefer the key whose item name appears in the merchant text
      var merch = String(r.Counterparty||'').toUpperCase();
      for (var li = 0; li < list.length; li++) {
        var item = list[li].split('|')[1]; if (!item) continue;
        if (merch.indexOf(item.trim().toUpperCase()) >= 0) { bk = list[li]; break; }
      }
    }
  }
  r.SuggDesc = prettify_(r.Counterparty); r.SuggCategory = cat; r.SuggBudgetKey = bk; r.Confidence = conf;
}

// ---------- endpoints used by the app ----------
function getInboxPending() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(INBOX_CFG.sheet); if (!sh) return { items:[], count:0 };
  var all = readInboxRows_(sh).filter(function(r){ return r.Status === 'pending'; });
  var alerts = all.filter(function(r){ return r.Kind === 'billalert'; }).map(function(r){ return {
    id:r.ID, card:r.Account, amountDue:r.Amount === '' ? null : Number(r.Amount),
    minDue:r.MinDue === '' ? null : Number(r.MinDue), dueDate:r.DueDate || r.Date }; });
  alerts.sort(function(a,b){ return String(a.dueDate) < String(b.dueDate) ? -1 : 1; });
  var rows = all.filter(function(r){ return r.Kind !== 'billalert'; });
  rows.sort(function(a,b){ return (b.Date > a.Date) ? 1 : (b.Date < a.Date ? -1 : 0); });
  var items = rows.map(function(r){ return {
    id:r.ID, kind:r.Kind, date:r.Date, amount:Number(r.Amount), account:r.Account, toAccount:r.ToAccount,
    counterparty:r.Counterparty, desc:r.SuggDesc, category:r.SuggCategory, budgetKey:r.SuggBudgetKey,
    confidence:r.Confidence, note:r.Note, balance:r.Balance === '' ? null : Number(r.Balance), balanceType:r.BalanceType, source:r.Source }; });
  return { items:items, count:items.length, alerts:alerts };
}
function setInboxStatus_(ss, id, status, note) {
  var sh = ss.getSheetByName(INBOX_CFG.sheet); if (!sh) return false;
  var ids = sh.getRange(2, 1, Math.max(1, sh.getLastRow()-1), 1).getValues();
  for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) {
    sh.getRange(i+2, 3).setValue(status); if (note !== undefined) sh.getRange(i+2, INBOX_COLS.length).setValue(note); return true;
  }
  return false;
}
// Runs a scan on demand (the app's Refresh button) and returns the fresh list.
function inboxScanNow() {
  try { scanGmailForTransactions(); } catch (e) { return { error: String(e), items: [], count: 0, alerts: [] }; }
  return getInboxPending();
}
function inboxDismiss(id) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return setInboxStatus_(ss, id, 'dismissed', 'dismissed in app');
}
// Called by doPost after a successful confirm: marks the row, learns the mapping.
function inboxAfterConfirm(ss, id, body) {
  setInboxStatus_(ss, id, 'confirmed', 'confirmed in app');
  var sh = ss.getSheetByName(INBOX_CFG.sheet); if (!sh) return;
  var rows = readInboxRows_(sh); var r = null;
  for (var i = 0; i < rows.length; i++) if (String(rows[i].ID) === String(id)) { r = rows[i]; break; }
  if (!r) return;
  if (r.Kind === 'debit' || r.Kind === 'credit') saveLearn_(ss, merchantKey_(r.Counterparty), body.description, body.category, body.budgetKey||'', body.toAccount||'');
}
// Called by doPost after a MANUAL add: auto-dismiss any pending inbox item that matches.
function inboxAutoDismiss(ss, dateISO, amount, account) {
  if (!account) return;
  // Fast path: the scan records how many items are pending. When that's zero
  // there is nothing to dismiss, so a manual save does no sheet reads at all.
  var props = PropertiesService.getScriptProperties();
  var pending = props.getProperty('INBOX_PENDING');
  if (pending !== null && Number(pending) === 0) return;

  var sh = ss.getSheetByName(INBOX_CFG.sheet); if (!sh) return;
  var last = sh.getLastRow(); if (last < 2) return;
  var fp = fingerprint_(dateISO, amount, account);
  // Read only the columns needed (ID, Status, Date, Amount, Account) in one go.
  var vals = sh.getRange(2, 1, last - 1, 7).getValues();
  var left = 0, hit = -1;
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][2]) !== 'pending') continue;
    var d = vals[i][4]; var iso = (d instanceof Date) ? dateToISO(d) : String(d);
    if (hit < 0 && fingerprint_(iso, vals[i][5], vals[i][6]) === fp) { hit = i + 2; }
    else left++;
  }
  if (hit > 0) {
    sh.getRange(hit, 3).setValue('auto');
    sh.getRange(hit, INBOX_COLS.length).setValue('matched manual entry');
    props.setProperty('INBOX_PENDING', String(left));
  }
}

// Caches the app shell so Ledger opens instantly and works offline.
// Transaction data still needs network (or is queued); this only caches the UI.
const CACHE = "ledger-shell-v11";
const ASSETS = ["index.html", "manifest.json", "icon.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const url = e.request.url;
  // Never cache calls to the Apps Script API — always go to network.
  if (url.includes("script.google.com")) return;
  e.respondWith(
    caches.match(e.request).then(hit => hit || fetch(e.request))
  );
});
